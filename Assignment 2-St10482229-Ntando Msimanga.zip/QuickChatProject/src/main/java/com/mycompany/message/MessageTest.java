package com.mycompany.message;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

public class MessageTest {

    public static void main(String[] args) throws IOException {

        Login login = new Login("k_1", "Password1!", "Kim", "Smith",
                "+27718693002");
        assertTrue(login.checkUserName());
        assertTrue(login.checkPasswordComplexity());
        assertTrue(login.checkCellPhoneNumber());
        assertTrue(login.loginUser("k_1", "Password1!"));

        Message first = new Message("+27718693002",
                "Hi Mike, can you join us for dinner tonight?");

        assertTrue(first.checkMessageID());
        assertTrue(first.getMessageID().matches("\\d{10}"));
        assertTrue(first.getMessageID().startsWith("00"));
        assertEquals("Message ready to send.", first.checkMessageLength());
        assertEquals("Cell phone number successfully captured.",
                first.checkRecipientCell());
        assertEquals("00:0:HITONIGHT", first.createMessageHash());
        assertEquals("Message successfully sent.", first.SentMessage(1));
        assertEquals(1, first.returnTotalMessagess());
        assertTrue(first.printMessages().contains("Hi Mike"));

        Message second = new Message("08575975889",
                "Hi Keegan, did you receive the payment?");

        assertTrue(second.checkRecipientCell().contains(
                "does not contain an international code"));
        assertEquals(second.checkRecipientCell(), second.SentMessage(1));
        assertEquals(1, second.returnTotalMessagess());

        Message longMessage = new Message("0212345678", 2,
                "+27718693002", repeat('A', 253));
        assertEquals("Message exceeds 250 characters by 3; please reduce the size.",
                longMessage.checkMessageLength());

        Message longID = new Message("12345678901", 3,
                "+27718693002", "Hello");
        assertFalse(longID.checkMessageID());

        Message discarded = new Message("0312345678", 3,
                "+27718693002", "Discard this message");
        assertEquals("Press 0 to delete the message.",
                discarded.SentMessage(new Scanner("2\n")));
        assertEquals("Message deleted.", discarded.SentMessage(0));
        assertEquals(1, discarded.returnTotalMessagess());

        Message storedMessage = new Message("0412345678", 4,
                "+27718693002", "Save this message");

        Path testFolder = Files.createTempDirectory("quickchat-test-");
        Path jsonFile = testFolder.resolve("stored_messages.json");

        try {
            first.storeMessage(jsonFile.toString());
            storedMessage.storeMessage(jsonFile.toString());

            String json = new String(Files.readAllBytes(jsonFile),
                    StandardCharsets.UTF_8);
            assertTrue(json.startsWith("["));
            assertTrue(json.endsWith("]\n"));
            assertTrue(json.contains("\"messageHash\": \"00:0:HITONIGHT\""));
            assertTrue(json.contains("Hi Mike, can you join us"));
            assertTrue(json.contains("Save this message"));
        } finally {
            Files.deleteIfExists(jsonFile);
            Files.deleteIfExists(testFolder);
        }

        System.out.println("All QuickChat tests passed.");
    }

    private static String repeat(char character, int count) {

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < count; i++) {
            result.append(character);
        }

        return result.toString();
    }

    private static void assertTrue(boolean result) {

        if (!result) {
            throw new AssertionError("Expected true.");
        }
    }

    private static void assertFalse(boolean result) {

        if (result) {
            throw new AssertionError("Expected false.");
        }
    }

    private static void assertEquals(String expected, String actual) {

        if (!expected.equals(actual)) {
            throw new AssertionError("Expected: " + expected + "; actual: " + actual);
        }
    }

    private static void assertEquals(int expected, int actual) {

        if (expected != actual) {
            throw new AssertionError("Expected: " + expected + "; actual: " + actual);
        }
    }
}

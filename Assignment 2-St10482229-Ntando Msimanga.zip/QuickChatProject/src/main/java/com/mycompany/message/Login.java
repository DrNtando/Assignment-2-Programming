package com.mycompany.message;

/**
 * @author Student
 */
public class Login {

    String username;
    String password;
    String firstName;
    String lastName;
    String cellPhoneNumber;

    public Login(String username, String password, String firstName,
                 String lastName, String cellPhoneNumber) {

        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    public boolean checkUserName() {

        if (username.contains("_") && username.length() <= 5) {
            return true;
        } else {
            return false;
        }
    }

    public boolean checkPasswordComplexity() {

        boolean capitalLetter = false;
        boolean number = false;
        boolean specialCharacter = false;

        if (password.length() < 8) {
            return false;
        }

        for (int i = 0; i < password.length(); i++) {

            char character = password.charAt(i);

            if (Character.isUpperCase(character)) {
                capitalLetter = true;
            }

            if (Character.isDigit(character)) {
                number = true;
            }

            if (!Character.isLetterOrDigit(character)) {
                specialCharacter = true;
            }
        }

        if (capitalLetter && number && specialCharacter) {
            return true;
        } else {
            return false;
        }
    }

    public boolean checkCellPhoneNumber() {

        return isValidCellPhoneNumber(cellPhoneNumber);
    }

    public static boolean isValidCellPhoneNumber(String cellPhoneNumber) {

        String phonePattern = "\\+\\d{1,3}\\d{1,10}$";

        return cellPhoneNumber != null && cellPhoneNumber.matches(phonePattern);
    }

    public String registerUser() {

        if (!checkUserName()) {

            return "Username is not correctly formatted, please ensure "
                    + "that your username contains an underscore and is "
                    + "no more than 5 characters in length.";

        } else if (!checkPasswordComplexity()) {

            return "Password is not correctly formatted, please ensure "
                    + "that the password contains at least 8 characters, "
                    + "a capital letter, a number and a special character.";

        } else if (!checkCellPhoneNumber()) {

            return "Cell phone number incorrectly formatted or "
                    + "does not contain international code.";

        } else {

            return "Username successfully captured\n"
                    + "Password successfully captured\n"
                    + "Cell phone number successfully added.";
        }
    }

    public boolean loginUser(String enteredUsername,
                             String enteredPassword) {

        if (enteredUsername.equals(username)
                && enteredPassword.equals(password)) {

            return true;

        } else {

            return false;
        }
    }

    public String returnLoginStatus(boolean loginSuccessful) {

        if (loginSuccessful) {

            return "Welcome " + firstName + " " + lastName
                    + ", it is great to see you again.";

        } else {

            return "Username or password incorrect, please try again.";
        }
    }
}

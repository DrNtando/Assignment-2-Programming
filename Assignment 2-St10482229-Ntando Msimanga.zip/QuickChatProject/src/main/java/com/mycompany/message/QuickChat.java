package com.mycompany.message;

import java.util.Scanner;

public class QuickChat {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Create a username: ");
        String username = input.nextLine();

        System.out.print("Create a password: ");
        String password = input.nextLine();

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        System.out.print("Enter your cell phone number with international code: ");
        String cellPhoneNumber = input.nextLine();

        Login login = new Login(username, password, firstName,
                lastName, cellPhoneNumber);
        System.out.println(login.registerUser());

        if (!login.checkUserName() || !login.checkPasswordComplexity()
                || !login.checkCellPhoneNumber()) {
            return;
        }

        System.out.print("Enter your username: ");
        String enteredUsername = input.nextLine();

        System.out.print("Enter your password: ");
        String enteredPassword = input.nextLine();

        boolean loginSuccessful = login.loginUser(enteredUsername,
                enteredPassword);
        System.out.println(login.returnLoginStatus(loginSuccessful));

        if (!loginSuccessful) {
            return;
        }

        System.out.println("Welcome to QuickChat.");
        System.out.print("How many messages would you like to create? ");

        int numberOfMessages;

        try {
            numberOfMessages = Integer.parseInt(input.nextLine().trim());
        } catch (NumberFormatException error) {
            System.out.println("Please enter a whole number.");
            return;
        }

        if (numberOfMessages < 1) {
            System.out.println("Please enter a number greater than zero.");
            return;
        }

        Message lastMessage = null;

        for (int i = 0; i < numberOfMessages; i++) {

            System.out.print("Enter the recipient's number with international code: ");
            String recipientCell = input.nextLine();

            System.out.print("Enter your message: ");
            String messageText = input.nextLine();

            Message newMessage = new Message(recipientCell, messageText);
            lastMessage = newMessage;

            System.out.println("Message ID generated: "
                    + newMessage.getMessageID());

            if (!newMessage.checkMessageLength().equals("Message ready to send.")) {
                System.out.println(newMessage.checkMessageLength());
                i--;
                continue;
            }

            if (!newMessage.checkRecipientCell().equals(
                    "Cell phone number successfully captured.")) {
                System.out.println(newMessage.checkRecipientCell());
                i--;
                continue;
            }

            String result = newMessage.SentMessage(input);
            System.out.println(result);

            if (result.equals("Press 0 to delete the message.")) {
                System.out.print("Press 0 to delete the message: ");
                String deleteChoice = input.nextLine();

                if ("0".equals(deleteChoice)) {
                    System.out.println(newMessage.SentMessage(0));
                }
            }
        }

        if (lastMessage != null) {
            System.out.println(lastMessage.printMessages());
            System.out.println("Total messages sent: "
                    + lastMessage.returnTotalMessagess());
        }
    }
}

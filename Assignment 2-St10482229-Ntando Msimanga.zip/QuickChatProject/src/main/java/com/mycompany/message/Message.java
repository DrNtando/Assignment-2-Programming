package com.mycompany.message;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Message {

    String messageID;
    int messageNumber;
    String recipientCell;
    String message;

    private static int numberOfMessages = 0;
    private static final ArrayList<Message> sentMessages = new ArrayList<Message>();
    private boolean sent = false;
    private boolean stored = false;

    public Message(String recipientCell, String message) {

        this(createID(numberOfMessages),
                numberOfMessages++, recipientCell, message);
    }

    private static String createID(int messageNumber) {

        return String.format("%02d%08d", messageNumber % 100,
                ThreadLocalRandom.current().nextInt(100_000_000));
    }

    public Message(String messageID, int messageNumber,
                   String recipientCell, String message) {

        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipientCell = recipientCell;
        this.message = message;
    }

    public String getMessageID() {

        return messageID;
    }

    public boolean checkMessageID() {

        return messageID != null && !messageID.isEmpty()
                && messageID.length() <= 10;
    }

    public String checkMessageLength() {

        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            return "Message exceeds 250 characters by "
                    + (message.length() - 250)
                    + "; please reduce the size.";
        }
    }

    public String checkRecipientCell() {

        if (Login.isValidCellPhoneNumber(recipientCell)) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does "
                    + "not contain an international code. Please correct "
                    + "the number and try again.";
        }
    }

    public String createMessageHash() {

        if (!checkMessageID()) {
            throw new IllegalStateException("Message ID must be 1 to 10 characters long.");
        }

        String[] words = message.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^\\p{L}\\p{N}]", "");
        String lastWord = words[words.length - 1]
                .replaceAll("[^\\p{L}\\p{N}]", "");

        return (messageID.substring(0, Math.min(2, messageID.length()))
                + ":" + messageNumber + ":" + firstWord + lastWord)
                .toUpperCase(Locale.ROOT);
    }

    public String SentMessage() {

        return SentMessage(new Scanner(System.in));
    }

    public String SentMessage(Scanner input) {

        System.out.println("Choose what to do with the message:");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message");
        System.out.print("Enter 1, 2, or 3: ");

        String enteredChoice = input.nextLine();

        try {
            return SentMessage(Integer.parseInt(enteredChoice.trim()));
        } catch (NumberFormatException error) {
            return "Please choose Send Message, Disregard Message, or Store Message.";
        }
    }

    public String SentMessage(int choice) {

        if (!checkMessageID()) {
            return "Message ID must be no more than 10 characters.";
        } else if (message.length() > 250) {
            return checkMessageLength();
        } else if (!Login.isValidCellPhoneNumber(recipientCell)) {
            return checkRecipientCell();
        }

        if (choice == 1) {

            if (!sent) {
                sentMessages.add(this);
                sent = true;
            }
            return "Message successfully sent.";

        } else if (choice == 2) {

            return "Press 0 to delete the message.";

        } else if (choice == 0) {

            return "Message deleted.";

        } else if (choice == 3) {

            try {
                storeMessage();
                return "Message successfully stored.";
            } catch (IOException error) {
                return "Could not store the message: " + error.getMessage();
            }

        } else {

            return "Please choose Send Message, Disregard Message, or Store Message.";
        }
    }

    public String printMessages() {

        if (sentMessages.isEmpty()) {
            return "No messages have been sent.";
        }

        StringBuilder result = new StringBuilder();

        for (Message sentMessage : sentMessages) {

            if (result.length() > 0) {
                result.append("\n\n");
            }

            result.append("Message ID: ").append(sentMessage.messageID)
                    .append("\nMessage Hash: ")
                    .append(sentMessage.createMessageHash())
                    .append("\nRecipient: ").append(sentMessage.recipientCell)
                    .append("\nMessage: ").append(sentMessage.message);
        }

        return result.toString();
    }

    public int returnTotalMessagess() {

        return sentMessages.size();
    }

    public void storeMessage() throws IOException {

        storeMessage("stored_messages.json");
    }

    public void storeMessage(String fileName) throws IOException {

        if (stored) {
            return;
        }

        Path file = Paths.get(fileName);
        String existing = Files.exists(file)
                ? new String(Files.readAllBytes(file), StandardCharsets.UTF_8).trim()
                : "[]";

        if (!existing.startsWith("[") || !existing.endsWith("]")) {
            throw new IOException("The JSON file does not contain a message list.");
        }

        String beforeEnd = existing.substring(0, existing.length() - 1).trim();
        String separator = beforeEnd.equals("[") ? "\n  " : ",\n  ";
        String updated = beforeEnd + separator + messageAsJson() + "\n]\n";

        Files.write(file, updated.getBytes(StandardCharsets.UTF_8));
        stored = true;
    }

    private String messageAsJson() {

        return "{\"messageID\": " + jsonString(messageID)
                + ", \"messageHash\": " + jsonString(createMessageHash())
                + ", \"recipientCell\": " + jsonString(recipientCell)
                + ", \"message\": " + jsonString(message) + "}";
    }

    private String jsonString(String value) {

        StringBuilder result = new StringBuilder("\"");

        for (int i = 0; i < value.length(); i++) {

            char character = value.charAt(i);

            if (character == '"' || character == '\\') {
                result.append('\\').append(character);
            } else if (character == '\n') {
                result.append("\\n");
            } else if (character == '\r') {
                result.append("\\r");
            } else if (character == '\t') {
                result.append("\\t");
            } else if (character < 32) {
                result.append(String.format("\\u%04x", (int) character));
            } else {
                result.append(character);
            }
        }

        return result.append('"').toString();
    }
}
